# The Joy of Travel

A simple static travel website focused on:
- Business Travel
- Group Travel
- Vacation Travel

## Files
- `index.html` — homepage
- `styles.css` — site styling
- `assets/homepage-concept.png` — visual design image

## Upload to GitHub
1. Create or open your GitHub repository.
2. Upload all files and folders from this project.
3. Commit the files.
4. Optional: enable GitHub Pages in repository Settings > Pages.

## Contact
The quote button currently uses `anthonyldougherty@gmail.com`.
